<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends Gkpos_Controller {

    function __construct() {
        parent::__construct();
        $this->site_title = $this->config->item('company');
        $this->load->model('Entry_Model');
        if (!$this->Entry_Model->is_logged_in()) {
            redirect('gkpos/entry');
        }
        $this->load->helper('gkpos');
        $this->load->model('Report_Model');
    }

    public function index() {
        $data['current_page'] = "report";
        $today_start = date($this->config->item('dateformat') . ' ' . $this->config->item('timeformat'), mktime(0, 0, 0));
        $today_end = date($this->config->item('dateformat') . ' ' . $this->config->item('timeformat'), mktime(23, 59, 59));
        $start_date_formatter = DateTime::createFromFormat($this->config->item('dateformat') . ' ' . $this->config->item('timeformat'), $today_start);
        $end_date_formatter = DateTime::createFromFormat($this->config->item('dateformat') . ' ' . $this->config->item('timeformat'), $today_end);
        $data['orderList'] = $this->Report_Model->search(array('start_date' => $start_date_formatter->format('Y-m-d H:i:s'), 'end_date' => $end_date_formatter->format('Y-m-d H:i:s'), 'is_by_closing' => 'no'))->result();
        $data['start_date'] = $start_date_formatter->format($this->config->item('dateformat'));
        $data['end_date'] = $end_date_formatter->format($this->config->item('dateformat'));
        $data['payment_options'] = $this->Report_Model->get_payment_options();
        $data['ordertype_options'] = $this->Report_Model->get_ordertype_options();
        $this->load->view('gkpos/report/index', $data, false);
    }

    public function filter() {
        $data['current_page'] = "report";
        $is_by_closing = isset($_POST['is_by_closing']) ? 'yes' : 'no';
        $start_date_value = '';
        $end_date_value = '';
        if ($is_by_closing == 'yes') {
            $start_date = DateTime::createFromFormat($this->config->item('dateformat'), $this->input->post('start_date') != null ? $this->input->post('start_date') : date($this->config->item('dateformat'), strtotime('today')));
            $end_date = DateTime::createFromFormat($this->config->item('dateformat'), $this->input->post('end_date') != null ? $this->input->post('end_date') : date($this->config->item('dateformat'), strtotime('today')));
            $start_date_value = $start_date->format('Y-m-d');
            $end_date_value = $end_date->format('Y-m-d');
        } else {
            $today_start = date($this->config->item('dateformat') . ' ' . $this->config->item('timeformat'), mktime(0, 0, 0));
            $today_end = date($this->config->item('dateformat') . ' ' . $this->config->item('timeformat'), mktime(23, 59, 59));

            $start_date = $this->input->post('start_date') != null ? $this->input->post('start_date') . ' ' . date($this->config->item('timeformat'), mktime(0, 0, 0)) : $today_start;
            $start_date_formatter = DateTime::createFromFormat($this->config->item('dateformat') . ' ' . $this->config->item('timeformat'), $start_date);
            $end_date = $this->input->post('end_date') != null ? $this->input->post('end_date') . ' ' . date($this->config->item('timeformat'), mktime(23, 59, 59)) : $today_end;
            $end_date_formatter = DateTime::createFromFormat($this->config->item('dateformat') . ' ' . $this->config->item('timeformat'), $end_date);
            $start_date_value = $start_date_formatter->format('Y-m-d H:i:s');
            $end_date_value = $end_date_formatter->format('Y-m-d H:i:s');
        }
        $order_type = $this->input->post('order_type');
        $pos_method = $this->input->post('pos_method');
        $online_method = $this->input->post('online_method');

        $filters = array(
            'order_type' => $order_type,
            'start_date' => $start_date_value,
            'end_date' => $end_date_value,
            'method' => $order_type != 'online' ? $pos_method : $online_method,
            'is_by_closing' => isset($_POST['is_by_closing']) ? 'yes' : 'no'
        );
        //debugPrint($filters);
        $data['orderList'] = $this->Report_Model->search($filters)->result();
        //debugPrint($data['orderList']);
        $this->load->view('gkpos/report/filtered', $data, false);
    }

    public function closeday() {
        $date = DateTime::createFromFormat($this->config->item('dateformat'), $this->input->post('closing_date'));
        $closing_date = array(
            'closing_date' => $date->format('Y-m-d')
        );
        if ($this->db->update('gkpos_order', $closing_date, array('closing_date' => NULL))) {
            echo json_encode(array('success' => true, 'message' => 'Days Closed for ' . $this->input->post('closing_date')));
        } else {
            echo json_encode(array('success' => false, 'message' => 'nothing to close'));
        }
    }

    public function showdate() {
        echo date('Y-m-d', strtotime('today'));
    }

}
