<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 right-item">
    <div class="sidebar-heading text-center text-uppercase">Settings</div>
    <a href="javascript:void(0)" onclick="getBaseAjaxPage('<?php echo site_url('gkpos/indexajax') ?>', 'Mainboard')"><div class="mainsystembg delivery-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_mainboard') ?></div></a>
    <a href="javascript:void(0)" onclick="getSettingPage('<?php echo site_url('gkpos/settings/general') ?>', 'general - info')"  ><div class="mainsystembg2 collection-bg  img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_general_setting') ?></div></a>
    <a href="#"><div class="mainsystembg2 waiting-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_bevarage_setting') ?></div></a>
    <a href="#"><div class="mainsystembg2 delivery-bg  img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_kitchen_setting') ?></div></a>
    <a href="#"><div class="mainsystembg2 collection-bg  img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_kitchen_text') ?></div></a>
    <a href="#"><div class="mainsystembg2 waiting-bg  img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_printer_setting') ?></div></a>
    <a href="#"><div class="mainsystembg collection-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_eft_card_setting') ?></div></a>
    <a href="javascript:void(0)" onclick="getBaseAjaxPage('<?php echo site_url('gkpos/indexajax') ?>', 'Mainboard')"><div class="mainsystembg delivery-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_mainboard') ?></div></a>
    <div class="sidebar-block">
        <div class="sidebar-heading text-center text-uppercase">Others-1</div>
        <div>
            content coming soon...
        </div>
    </div>
    <div class="sidebar-block">
        <div class="sidebar-heading text-center text-uppercase">Others-2</div>
        <div>
            content coming soon...
        </div>
    </div>
</div>