<?php

class Report_Model extends MY_Model {

    function __construct() {
        parent::__construct();
    }

}
