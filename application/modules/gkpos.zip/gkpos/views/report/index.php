<style>
    .report-button .btn {
        margin: 0 5px;
        padding: 10px;
        width: 85px;
    }
</style>


<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
    <fieldset>
        <div class="row">
            <div class="report-button pull-right">
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 text-center text-uppercase btn btn-large btn-info">Print</div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 text-center text-uppercase btn btn-large btn-warning">import</div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 text-center text-uppercase btn btn-large btn-success">export</div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 text-center text-uppercase btn btn-large btn-danger">Delete</div>
            </div>
        </div>
        <div class="clearfix" style="margin: 5px 0px 5px 0px"></div>
        <div class="row">
            <form>
                <table class="table table-bg-color table-responsive">
                    <tr>
                        <th>Start From</th>
                        <th>End At </th>
                        <th>Order Type</th>
                        <th>Pay By</th>
                        <th>&nbsp;</th>
                    </tr>
                    <tr>
                        <td><input class="form-control" type="text" name="from_date" id="FromDate"></td>
                        <td><input class="form-control" type="text" name="from_date" id="FromDate"></td>
                        <td><input class="form-control" type="text" name="from_date" id="FromDate"></td>
                        <td><input class="form-control" type="text" name="from_date" id="FromDate"></td>
                        <td><button class="btn btn-success btn-large" type="button"><?php echo "Submit" ?></button></td>
                    </tr>
                </table>
            </form>
        </div>
        <div class="clearfix" style="margin: 5px 0px 5px 0px"></div>
        <div class="row">
            <form>
                <table class="table table-responsivev table-bordered">
                    <tr>
                        <th class="text-left"><input type="checkbox" class="checkbox-inline">SL#</th>
                        <th>Time</th>
                        <th>Customer</th>
                        <th>Type</th>
                        <th>Total</th>
                        <th>Tendered</th>
                        <th>Change</th>
                        <th>Update</th>
                    </tr>
                    <tr>
                        <td><input type="checkbox" class="checkbox-inline"></td>
                        <td>07/01/2017 00:53:05</td>
                        <td>Bill</td>
                        <td>Collection</td>
                        <td><?php echo $this->config->item('currency_symbol') . "25" ?></td>
                        <td><?php echo $this->config->item('currency_symbol') . "50" ?></td>
                        <td><?php echo $this->config->item('currency_symbol') . "25" ?></td>
                        <td>Edit | Print | Delete</td>
                    </tr>
                </table>
            </form>
        </div>
    </fieldset>
</div>