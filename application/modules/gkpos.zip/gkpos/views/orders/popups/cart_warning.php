<a class='warningPopup cartWarning' href="#cartWarning" style="display:none"></a>
<div style="display:none">
    <div id="cartWarning" class="popupouter">
        <div class="popup-header row">
            <div id="cartWarningHeader" class="warningPopupHeader text-uppercase col-lg-10 col-md-10 col-sm-10 col-xs-10 pull-left "></div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pull-left closeWarningPopup closeServiceChargePopup text-center times">&times;</div>
        </div>
        <div class="popup-body row">
            <div id="cartWarningContent" class="warningPopupContent col-lg-12 col-md-12 col-sm-12 col-xs-12"></div>
        </div>
        <div class="popup-footer row">
            <a href="javascript:void(0)" class="closeWarningPopup closeServiceChargePopup text-center btn btn-default col-md-offset-5 col-md-2 col-md-offset-5"><?php echo $this->lang->line('gkpos_ok') ?></a>
        </div>
    </div>
</div>
