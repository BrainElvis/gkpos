<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 left-item">
    <div class="sidebar-heading text-center text-uppercase">Help Links</div>
    <a href="<?php echo site_url('gkpos') ?>"><div class="mainsystembg delivery-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_mainboard') ?></div></a>
    <a href="#"><div class="mainsystembg2 collection-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_customer') ?></div></a>
    <a href="#"><div class="mainsystembg waiting-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_order') ?></div></a>
    <a href="#"><div class="mainsystembg2 delivery-bg  img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_expense') ?></div></a>
    <a href="#"><div class="mainsystembg collection-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_view_report') ?></div></a>
    <a href="#"><div class="mainsystembg2 waiting-bg  img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_stock_control') ?></div></a>
    <a href="#"><div class="mainsystembg2 collection-bg  img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_system_log_register') ?></div></a>
    <a href="<?php echo site_url('gkpos') ?>"><div class="mainsystembg delivery-bg img-responsive text-uppercase"><?php echo $this->lang->line('gkpos_mainboard') ?></div></a>
    <div class="sidebar-block">
        <div class="sidebar-heading text-center text-uppercase">Others-1</div>
        <div>
            content coming soon...
        </div>
    </div>
    <div class="sidebar-block">
        <div class="sidebar-heading text-center text-uppercase">Others-2</div>
        <div>
            content coming soon...
        </div>
    </div>
</div>